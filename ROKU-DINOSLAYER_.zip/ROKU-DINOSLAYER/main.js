var config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 700 },
            debug: false
        }
    },
    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

var score;
var scoreText;
var player;
var platforms;
let cursors;
var weapon;
var bullets;
var fireKey;
var lastFired = 0;
var enemies;
var enemyWeapons;
var enemyBullets;
var gameOverText;
var retryButton;

function preload () {
    // CARGA DE FONDOS Y PLATAFORMAS
    this.load.image('sky3', 'sprites/background/sky.png');
    this.load.image('sky1', 'sprites/background/houses&trees_bg (1).png');
    this.load.image('sky2', 'sprites/background/houses (1).png');
    this.load.image('ground1', 'sprites/plataforms/fence(2).png');

    // CARGA DE BALAS Y ARMAS
    this.load.image('bullet', 'sprites/guns/Bullet2.png');
    this.load.image('gun', 'sprites/guns/gun2.png');
    this.load.image('gun2', 'sprites/guns/gun.png');

    // CARGA DE SPRITESHEETS DE ENEMIGOS
    this.load.spritesheet('enemy1', 'sprites/sprites/enemy1.png', { frameWidth: 24, frameHeight: 20 });
    this.load.spritesheet('enemy2', 'sprites/sprites/enemy2.png', { frameWidth: 24, frameHeight: 20 });
    this.load.spritesheet('enemy3', 'sprites/sprites/enemy3.png', { frameWidth: 24, frameHeight: 20 });

    // CARGA DE SPRITESHEET DEL JUGADOR
    this.load.spritesheet('player', 'sprites/sprites/DinoSprites - vita1.png', { frameWidth: 24, frameHeight: 20 });

    //CARGA DE LOS SONIDOS
    this.load.audio('disparo', 'sounds/pkm-sound-effect-243959.mp3');
    this.load.audio('musica', 'sounds/es_features_song-maker.mp3');
}

function create () {

    //AÑADE MUSICA DENTRO DEL JUEGO
    const music = this.sound.add('musica', { loop: true, volume: 0.05 });
    music.play();


    // FONDOS
    this.add.image(400, 300, 'sky3');
    this.add.image(400, 300, 'sky1');
    this.add.image(400, 300, 'sky2');

    // PUNTUACIÓN
    score = 0;
    scoreText = this.add.text(16, 16, 'SCORE: 0', { fontSize: '32px', fill: '#fff' });

    // PLATAFORMAS
    platforms = this.physics.add.staticGroup();

    var Plataforma = platforms.create(400, 350, 'ground1').setScale(0.5, 0.5).refreshBody();
    Plataforma.body.setSize(Plataforma.displayWidth, 50).setOffset(0, Plataforma.displayHeight - 100);

    var Plataforma1 = platforms.create(800, 250, 'ground1').setScale(0.3, 0.3).refreshBody();
    Plataforma1.body.setSize(575, 65).setOffset(0, Plataforma.displayHeight - 280);

    var Plataforma2 = platforms.create(20, 250, 'ground1').setScale(0.3, 0.3).refreshBody();
    Plataforma2.body.setSize(575, 65).setOffset(0, Plataforma.displayHeight - 280);

    var Plataforma3 = platforms.create(400, 50, 'ground1').setScale(0.3, 0.3).refreshBody();
    Plataforma3.body.setSize(575, 65).setOffset(0, Plataforma.displayHeight - 280);

    // JUGADOR
    player = this.physics.add.sprite(400, 400, 'player').setScale(3);
    player.setBounce(0.2);
    player.setCollideWorldBounds(true);

    // ANIMACIONES DEL JUGADOR
    this.anims.create({
        key: 'Walk',
        frames: this.anims.generateFrameNumbers('player', { start: 0, end: 3 }),
        frameRate: 10,
        repeat: -1
    });

    this.anims.create({
        key: 'turn',
        frames: [ { key: 'player', frame: 0 } ],
        frameRate: 20
    });

    // ANIMACIONES DE ENEMIGOS
    this.anims.create({
        key: 'enemy1_walk',
        frames: this.anims.generateFrameNumbers('enemy1', { start: 0, end: 3 }),
        frameRate: 8,
        repeat: -1
    });

    this.anims.create({
        key: 'enemy2_walk',
        frames: this.anims.generateFrameNumbers('enemy2', { start: 0, end: 3 }),
        frameRate: 8,
        repeat: -1
    });

    this.anims.create({
        key: 'enemy3_walk',
        frames: this.anims.generateFrameNumbers('enemy3', { start: 0, end: 3 }),
        frameRate: 8,
        repeat: -1
    });

    // COLISIONES JUGADOR Y PLATAFORMAS
    this.physics.add.collider(player, platforms);

    // CONTROLES
    cursors = this.input.keyboard.createCursorKeys();
    fireKey = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);

    // BALAS DEL JUGADOR
    bullets = this.physics.add.group({ defaultKey: 'bullet', maxSize: 10 });

    this.physics.add.collider(bullets, platforms, (bullet) => {
        bullets.killAndHide(bullet);
        bullet.body.enable = false;
    }, null, this);

    // ARMA DEL JUGADOR
    weapon = this.add.image(0, 0, 'gun');
    weapon.setScale(1);
    weapon.setOrigin(0.5, 0.5);

    // ENEMIGOS
    enemies = this.physics.add.group();

    const enemy1 = enemies.create(50, 180, 'enemy1').setScale(3);
    enemy1.patrolBounds = { left: 20, right: 200 };
    enemy1.direction = 1;
    enemy1.anims.play('enemy1_walk');
    enemy1.isShooting = false;

    const enemy2 = enemies.create(750, 180, 'enemy2').setScale(3);
    enemy2.patrolBounds = { left: 600, right: 780 };
    enemy2.direction = 1;
    enemy2.anims.play('enemy2_walk');
    enemy2.isShooting = false;

    const enemy3 = enemies.create(400, 0, 'enemy3').setScale(3);
    enemy3.patrolBounds = { left: 250, right: 550 };
    enemy3.direction = 1;
    enemy3.anims.play('enemy3_walk');
    enemy3.isShooting = false;

    this.physics.add.collider(enemies, platforms);

    // ARMAS DE ENEMIGOS
    [enemy1, enemy2, enemy3].forEach((enemy) => {
        const gun = this.add.image(enemy.x, enemy.y, 'gun2').setScale(1).setOrigin(0.5);
        enemy.gun = gun;
    });

    // BALAS DE ENEMIGOS
    enemyBullets = this.physics.add.group({ defaultKey: 'bullet', maxSize: 10 });

    this.physics.add.collider(enemyBullets, platforms, (bullet) => {
        enemyBullets.killAndHide(bullet);
        bullet.body.enable = false;
    }, null, this);

    // COLISIONES BALAS DEL JUGADOR A LOS ENEMIGOS
    this.physics.add.overlap(bullets, enemies, (bullet, enemy) => {
        bullets.killAndHide(bullet);
        bullet.body.enable = false;

        enemy.disableBody(true, true);
        if (enemy.gun) enemy.gun.destroy();

        score += 10;
        scoreText.setText('SCORE: ' + score);

        // Revisar si todos los enemigos murieron
        if (enemies.countActive(true) === 0) {
            endGame(this, '¡GANASTE!');
            music.stop();
        }
    }, null, this);

    // COLISIONES BALAS DE ENEMIGOS AL JUGADOR
    this.physics.add.overlap(enemyBullets, player, (player, bullet) => {
        enemyBullets.killAndHide(bullet);
        bullet.body.enable = false;

        endGame(this, 'PERDISTE');
        music.stop();
    }, null, this);

    // LETRERO DE GAME OVER / GANASTE
    gameOverText = this.add.text(400, 300, '', { fontSize: '64px', fill: '#fff' });
    gameOverText.setOrigin(0.5);
    gameOverText.setVisible(false);

    
    // BOTÓN DE REINTENTAR
    retryButton = this.add.text(400, 400, 'REINTENTAR', { fontSize: '32px', fill: '#fff', backgroundColor: '#000' })
        .setOrigin(0.5)
        .setPadding(10)
        .setInteractive()
        .setVisible(false);

    retryButton.on('pointerdown', () => {
        this.scene.restart();

          
    });

}

function endGame(scene, message) {
    gameOverText.setText(message);
    gameOverText.setVisible(true);
    retryButton.setVisible(true);

    // ELIMINA AL JUGADOR Y A SU ARMA
    if (player) {
        player.destroy();
        player = null;
    }
    if (weapon) {
        weapon.destroy();
        weapon = null;
    }
    //ELIMINA A LOS ENEMIGOS
    enemies.getChildren().forEach((enemy) => {
        if (enemy.gun) {
            enemy.gun.destroy();
        }
    });
    
    enemies.clear(true, true);
}
function update(time) {
    if (!player || !player.active) return;

    // MOVIMIENTO DEL JUGADOR
    if (cursors.left.isDown) {
        player.setVelocityX(-160);
        player.anims.play('Walk', true);
        player.flipX = true;
    } else if (cursors.right.isDown) {
        player.setVelocityX(160);
        player.anims.play('Walk', true);
        player.flipX = false;
    } else {
        player.setVelocityX(0);
        player.anims.play('turn');
    }

    if (cursors.up.isDown && player.body.touching.down) {
        player.setVelocityY(-570);
    }

    // POSICIONAMIENTO DEL ARMA DEL JUGADOR
    weapon.setPosition(player.x + (player.flipX ? -20 : 20), player.y + 12);
    weapon.setFlipX(player.flipX);

    // DISPARO DEL JUGADOR
    if (Phaser.Input.Keyboard.JustDown(fireKey) && bullets.countActive(true) < bullets.maxSize) {
        const bullet = bullets.get(weapon.x + 50, weapon.y);
        if (bullet) {
            bullet.setActive(true);
            bullet.setScale(1.5);
            bullet.setVisible(true);
            bullet.body.enable = true;
            bullet.body.allowGravity = false;
            bullet.setVelocityX(weapon.flipX ? -300 : 300);

            const disparoSound = this.sound.add('disparo');
            disparoSound.play({ volume: 0.1, seek: 0.3 });

            this.time.delayedCall(150, () => {
                disparoSound.stop();
            });

        }
    }

    // LÓGICA DE ENEMIGOS
    enemies.getChildren().forEach((enemy) => {
        if (!enemy.active) return;

        // PATRULLA
        if (enemy.x <= enemy.patrolBounds.left) {
            enemy.direction = 1;
            enemy.flipX = false;
        } else if (enemy.x >= enemy.patrolBounds.right) {
            enemy.direction = -1;
            enemy.flipX = true;
        }
        enemy.setVelocityX(40 * enemy.direction);

        // POSICIÓN DEL ARMA
        if (enemy.gun) {
            enemy.gun.setPosition(enemy.x + (enemy.direction > 0 ? 20 : -20), enemy.y + 20);
            enemy.gun.setFlipX(enemy.direction < 0);
        }

        // DISPARO DE ENEMIGOS
        const distanceX = Math.abs(enemy.x - player.x);
        const distanceY = Math.abs(enemy.y - player.y);
        const withinSight = distanceX < 250 && distanceY < 100 &&
            ((enemy.direction > 0 && player.x > enemy.x) || (enemy.direction < 0 && player.x < enemy.x));

        if (withinSight && time > lastFired + 2000) {
            const bullet = enemyBullets.get(enemy.x + 40, enemy.y + 5);
            if (bullet) {
                bullet.setActive(true);
                bullet.setScale(1.5);
                bullet.setVisible(true);
                bullet.body.enable = true;
                bullet.setVelocityX(enemy.direction * 300);
                bullet.body.allowGravity = false;
                lastFired = time;


                const disparoSound2 = this.sound.add('disparo');
                disparoSound2.play({ volume: 0.1, seek: 0.3 });

                this.time.delayedCall(150, () => {
                    disparoSound2.stop();
                });
            }
            
        }
    });
}